package com.wiseassblog.spacenotes

import android.app.Application


class SpaceNotes: Application() {

    override fun onCreate() {
        super.onCreate()

    }
}